function [] = blurring( IM, n )
%CO Summary of this function goes here
%   Detailed explanation goes here
h = fspecial('average', n); % create n*n averaging filter
f = IM;
g = imfilter(f, h); % apply filter using convolution
imshow(g); % display output
end