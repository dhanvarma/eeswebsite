function [] = roberts(A)
%ROBERTS
%  1  0
%  0 -1
B=rgb2gray(A);
figure;
imshow(B)
pause(2)
I=double(B);

for i=1:size(I,1)-1
    for j=1:size(I,2)-1
        mx = (I(i,j)-I(i+1,j+1));
        my = (I(i+1,j)-I(i,j+1));
        B(i,j) = sqrt(mx.^2+my.^2);
    end
end
figure;
imshow(B); title('Roberts gradient');
end

