function [] = edge(IM)

output = IM;
I = double(IM);

for i=1:size(I,1)-2
    for j=1:size(I,2)-2
        output(i,j) = (I(i+1,j) + I(i,j+1) + I(i+1,j+2) + I(i+2,j+1) - 4*I(i+1,j+1));
    end
end
imshow(output); 
end